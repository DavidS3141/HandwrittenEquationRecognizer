clear;
close all;
%%
image = imread('../data/test/08.png');

figure;
imshow(image);

HER(image);

%%
image = imread('../data/test/09.png');

figure;
imshow(image);

HER(image);